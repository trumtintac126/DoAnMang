/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;


import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import static java.awt.image.ImageObserver.WIDTH;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PiePlot3D;
import org.jfree.data.general.DefaultPieDataset;

/**
 *
 * @author tam
 */
public class NewClass extends JFrame implements ActionListener {

    private int[][] matrixA, matrixB, matrixC, matrixD;
    Random rd = new Random();
    DefaultPieDataset datasetC = new DefaultPieDataset();
    JFreeChart chartC = ChartFactory.createPieChart3D("", datasetC, true, true, false);
    DefaultPieDataset datasetD = new DefaultPieDataset();
    JFreeChart chartD = ChartFactory.createPieChart3D("", datasetD, true, true, false);
    JButton btnSaveAB, btnReadAB, btnSolve, btnSaveCD, btnReset;
    JTextField tfRowA, tfColumnA, tfRowB, tfColumnB, tfSleep, tfThread;
    JTextArea taA, taB;
    JLabel lbA, lbB;
    boolean isFirstSolve;

    public NewClass() {
        super("Cộng và nhân 2 ma trận");
        init();
        initcomponents();
        pack();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnSaveAB) {

            if (checkError(tfRowA)) {
                return;
            }
            int rA = Integer.parseInt(tfRowA.getText());
            int cA = Integer.parseInt(tfColumnA.getText());
            int rB = Integer.parseInt(tfRowB.getText());
            int cB = Integer.parseInt(tfColumnB.getText());
            String strA = "";
            for (int i = 0; i < rA; i++) {
                for (int j = 0; j < cA; j++) {
                    strA += rd.nextInt(10) + "-";
                }
            }
            writeFile("saveA.txt", strA.substring(0, strA.length() - 1));
            String strB = "";
            for (int i = 0; i < rB; i++) {
                for (int j = 0; j < cB; j++) {
                    strB += rd.nextInt(10) + "-";
                }
            }
            writeFile("saveB.txt", strB.substring(0, strB.length() - 1));
            //khoi tao 2 ma tran A va B
            matrixA = new int[rA][cA];
            matrixB = new int[rB][cB];

            btnSaveAB.setEnabled(false);
            btnReadAB.setEnabled(true);
            JOptionPane.showMessageDialog(this, "Lưu 2 ma trận thành công!");
        } else if (e.getSource() == btnReadAB) {
            int[] a = readFileByFileReader("saveA.txt");
            int[] b = readFileByFileReader("saveB.txt");
            if (a.length == 0 || b.length == 0) {
                JOptionPane.showMessageDialog(this, "File ko tồn tại hoặc dư liệu rỗng!");
            }
            String strA = "", strB = "";
            for (int i = 0; i < matrixA.length; i++) {
                for (int j = 0; j < matrixA[0].length; j++) {
                    matrixA[i][j] = a[i * matrixA[0].length + j];
                    strA += matrixA[i][j] + " ";
                }
                strA += "\n";
            }
            for (int i = 0; i < matrixB.length; i++) {
                for (int j = 0; j < matrixB[0].length; j++) {
                    matrixB[i][j] = b[i * matrixB[0].length + j];
                    strB += matrixB[i][j] + " ";
                }
                strB += "\n";
            }
            taA.setText(strA);
            taB.setText(strB);
            btnSaveAB.setEnabled(false);
            btnReadAB.setEnabled(false);
            btnSolve.setEnabled(true);
        } else if (e.getSource() == btnSolve) {
            if (checkError(tfSleep) || checkError(tfThread)) {
                return;
            }
            if (!isFirstSolve) {
                isFirstSolve = !isFirstSolve;
                int row = matrixA.length;
                String title = "Biểu đồ thể hiện thời gian nhân 2 ma trận \ntạo ma trận " + row + " X " + row + " với thời gian trễ " + tfSleep.getText() + " ms";
                chartC.setTitle(title);
                String titleD = "Biểu đồ thể hiện thời gian cộng 2 ma trận \ntạo ma trận " + row + " X " + row + " với thời gian trễ " + tfSleep.getText() + " ms";
                chartD.setTitle(titleD);
                tfSleep.setEditable(false);
                lbA.setText("Nhân 2 ma trận");
                lbB.setText("Cộng 2 ma trận");
                tfRowA.setEditable(false);
                btnSaveCD.setEnabled(true);
            }

            int row = matrixA.length;
            int column = matrixB[0].length;
            matrixC = new int[row][column];
            matrixD = new int[row][column];
            int thread = Integer.parseInt(tfThread.getText());

            ThreadPoolExecutor poolC = new ThreadPoolExecutor(thread, thread, 1, TimeUnit.SECONDS, new ArrayBlockingQueue<>(row * column));
            ThreadPoolExecutor poolD = new ThreadPoolExecutor(thread, thread, 1, TimeUnit.SECONDS, new ArrayBlockingQueue<>(row * column));

            for (int i = 0; i < row; i++) {
                for (int j = 0; j < column; j++) {
                    poolC.execute(new MatrixThread(i, j));
                    poolD.execute(new AddMatrixThread(i, j));
                }
            }
            poolC.shutdown();
            new Thread(new Runnable() {
                @Override
                public void run() {
                    long time = System.currentTimeMillis();
                    while (!poolC.isTerminated()) {
                        datasetC.setValue(tfThread.getText() + " luồng", new Double(System.currentTimeMillis() - time));
                    }
                }
            }).start();

            poolD.shutdown();
            new Thread(new Runnable() {
                @Override
                public void run() {
                    long time = System.currentTimeMillis();
                    while (!poolD.isTerminated()) {
                        datasetD.setValue(tfThread.getText() + " luồng", new Double(System.currentTimeMillis() - time));
                    }
                }
            }).start();

        } else if (e.getSource() == btnSaveCD) {
            writeFile("saveC.txt", taA.getText());
            writeFile("saveD.txt", taB.getText());
            btnSaveCD.setEnabled(false);
            JOptionPane.showMessageDialog(this, "Lưu kết quả thành công!");
        } else {
            tfRowA.setText("");
            tfRowB.setText("");
            tfColumnA.setText("");
            tfColumnB.setText("");
            taA.setText("");
            taB.setText("");
            tfSleep.setText("");
            tfThread.setText("");
            btnSaveAB.setEnabled(true);
            btnReadAB.setEnabled(false);
            btnSolve.setEnabled(false);
            btnSaveCD.setEnabled(false);
            chartC.setTitle("Biểu đồ thể hiện thời gian nhân 2 ma trận");
            chartD.setTitle("Biểu đồ thể hiện thời gian cộng 2 ma trận");
            tfSleep.setEditable(true);
            tfRowA.setEditable(true);
            datasetC.clear();
            datasetD.clear();
            lbA.setText("Ma trận A");
            lbB.setText("Ma trận B");
            isFirstSolve=!isFirstSolve;
        }

    }

    public static void main(String[] args) {
        new NewClass().setVisible(true);
    }

    //------------------------------------------PRIVATE--------------------------------//
    private void init() {
        setPreferredSize(new Dimension(800, 600));
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        btnSaveAB = new JButton("Lưu 2 ma trận vào file");
        btnReadAB = new JButton("Đọc 2 ma trận từ file");
        btnSolve = new JButton("Cộng và nhân 2 ma trận");
        btnSaveCD = new JButton("Lưu kết quả vào file");
        btnReset = new JButton("Làm mới");

        tfRowA = new JTextField(5);
        tfRowA.setName("Hàng A");
        tfColumnA = new JTextField(5);
        tfColumnA.setEditable(false);
        tfRowB = new JTextField(5);
        tfRowB.setEditable(false);
        tfColumnB = new JTextField(5);
        tfColumnB.setEditable(false);
        tfSleep = new JTextField(5);
        tfSleep.setName("Thời gian trễ");
        tfThread = new JTextField(5);
        tfThread.setName("Số luồng");

        taA = new JTextArea(20, 20);
        taB = new JTextArea(20, 20);
        lbA = new JLabel("Ma trận A");
        lbB = new JLabel("Ma trận B");

        btnSaveAB.addActionListener(this);
        btnReadAB.addActionListener(this);
        btnSolve.addActionListener(this);
        btnSaveCD.addActionListener(this);
        btnReset.addActionListener(this);
        tfRowA.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {
            }

            @Override
            public void keyPressed(KeyEvent e) {
            }

            @Override
            public void keyReleased(KeyEvent e) {
                try {
                    int temp = Integer.parseInt(tfRowA.getText());
                    tfColumnA.setText(temp + "");
                    tfRowB.setText(temp + "");
                    tfColumnB.setText(temp + "");
                } catch (Exception ex) {
                    tfRowA.setText("");
                    tfColumnA.setText("");
                    tfRowB.setText("");
                    tfColumnB.setText("");
                }
            }
        });
        
        btnReadAB.setEnabled(false);
        btnSolve.setEnabled(false);
        btnSaveCD.setEnabled(false);
    }

    private void initcomponents() {
        //panel top
        JPanel pnHeader = new JPanel(new GridLayout(3, 3, 30, 5));
        add(pnHeader, BorderLayout.NORTH);
        pnHeader.setBorder(BorderFactory.createTitledBorder("Chọn tác vụ:"));
        pnHeader.add(btnSaveAB);
        pnHeader.add(btnReadAB);
        pnHeader.add(btnSolve);
        pnHeader.add(btnSaveCD);
        pnHeader.add(btnReset);
        pnHeader.add(new JLabel());

        JPanel pnSleep = new JPanel(new FlowLayout(FlowLayout.LEFT));
        pnSleep.add(new JLabel("Thời gian trễ: "));
        pnSleep.add(tfSleep);
        pnSleep.add(new JLabel("(ms)"));
        JPanel pnThread = new JPanel(new FlowLayout(FlowLayout.LEFT));
        pnThread.add(new JLabel("Số luồng: "));
        pnThread.add(tfThread);
        pnThread.add(new JLabel("(Luồng)"));

        pnHeader.add(pnSleep);
        pnHeader.add(pnThread);
        //panel center
        JPanel pnCenter = new JPanel(new BorderLayout());
        add(pnCenter, BorderLayout.CENTER);
        //panel center header
        JPanel pnCenterTop = new JPanel(new GridLayout(1, 2));
        pnCenter.add(pnCenterTop, BorderLayout.NORTH);

        JPanel pnLabelA = new JPanel(new BorderLayout());
        JPanel pnLabelAA = new JPanel(new FlowLayout(FlowLayout.CENTER));
        pnLabelAA.add(lbA);
        pnLabelA.add(pnLabelAA, BorderLayout.NORTH);
        JPanel pnTfA = new JPanel(new FlowLayout(FlowLayout.CENTER));
        pnTfA.add(tfRowA);
        pnTfA.add(new JLabel("X"));
        pnTfA.add(tfColumnA);
        pnLabelA.add(pnTfA, BorderLayout.CENTER);
        pnCenterTop.add(pnLabelA);

        JPanel pnLabelB = new JPanel(new BorderLayout());
        JPanel pnLabelBB = new JPanel(new FlowLayout(FlowLayout.CENTER));
        pnLabelBB.add(lbB);
        pnLabelB.add(pnLabelBB, BorderLayout.NORTH);
        JPanel pnTfB = new JPanel(new FlowLayout(FlowLayout.CENTER));
        pnTfB.add(tfRowB);
        pnTfB.add(new JLabel("X"));
        pnTfB.add(tfColumnB);
        pnLabelB.add(pnTfB, BorderLayout.CENTER);
        pnCenterTop.add(pnLabelB);

        JPanel pnCenterMain = new JPanel(new GridLayout(1, 2, 10, 0));
        pnCenter.add(pnCenterMain, BorderLayout.CENTER);
        JScrollPane scroolA = new JScrollPane(taA);
        pnCenterMain.add(scroolA);
        JScrollPane scroolB = new JScrollPane(taB);
        pnCenterMain.add(scroolB);

        JPanel pnFooter = new JPanel(new GridLayout(1, 2));
        add(pnFooter, BorderLayout.SOUTH);

        chartC.setTitle("Biểu đồ thể hiện thời gian nhân 2 ma trận");
        PiePlot3D plotC = (PiePlot3D) chartC.getPlot();
        plotC.setForegroundAlpha(0.5f);
        JFreeChart pieChart = chartC;
        ChartPanel chartPanel = new ChartPanel(pieChart);
        chartPanel.setPreferredSize(new Dimension(500, 200));
        chartPanel.setMouseWheelEnabled(true);
        chartPanel.setZoomAroundAnchor(true);

        chartD.setTitle("Biểu đồ thể hiện thời gian cộng 2 ma trận");
        PiePlot3D plotD = (PiePlot3D) chartD.getPlot();
        plotD.setForegroundAlpha(0.6f);
        JFreeChart pieChart1 = chartD;
        ChartPanel chartPanel1 = new ChartPanel(pieChart1);
        chartPanel1.setPreferredSize(new Dimension(500, 200));
        chartPanel1.setMouseWheelEnabled(true);
        chartPanel1.setZoomAroundAnchor(true);

        pnFooter.add(chartPanel);
        pnFooter.add(chartPanel1);

    }

    private boolean checkError(JTextField tf) {
        String s = tf.getText().toString();
        if (s.equals("")) {
            JOptionPane.showMessageDialog(this, "Nhập rỗng " + tf.getName() + "!");
            tf.requestFocus();
            return true;
        }
        try {
            if (Integer.parseInt(s) < 1) {
                JOptionPane.showMessageDialog(this, "Giá trị " + tf.getName() + " phải lớn hơn 0!");
                tf.requestFocus();
                return true;
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, tf.getName() + " phải nhập số!");
            e.printStackTrace();
            tf.requestFocus();
            return true;
        }
        return false;
    }

    private void writeFile(String path, String content) {
        try (FileWriter fos = new FileWriter(path, false)) {
            //try catch resourse. sử dụng xong tự động giải phóng.
            fos.write(content);
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    private int[] readFileByFileReader(String path) {
        String content = "";
        FileReader fis = null;
        try {
            fis = new FileReader(path);
            int ch;
            while ((ch = fis.read()) != -1) {
                content += (char) ch;
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        } finally {
            if (fis != null) {
                try {
                    fis.close();
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        }
        int[] temp = new int[content.length()];
        int i = 0;
        for (String s : content.split("-")) {
            temp[i++] = Integer.parseInt(s);
        }
        return temp;
    }

    public class MatrixThread implements Runnable {

        int s1, s2;

        public MatrixThread(int s1, int s2) {
            this.s1 = s1;
            this.s2 = s2;
        }

        @Override
        public void run() {

            for (int i = 0; i < matrixA[0].length; i++) {
                matrixC[s1][s2] += matrixA[s1][i] * matrixB[i][s2];
            }
            String strC = "";
            for (int i = 0; i < matrixC.length; i++) {
                for (int j = 0; j < matrixC[0].length; j++) {
                    if (matrixC[i][j] == 0) {
                        strC += "  ";
                    } else {
                        strC += matrixC[i][j] + " ";
                    }
                }
                strC += "\n";
            }
            final String temp = strC;
            SwingUtilities.invokeLater(new Runnable() {
                public void run() {
                    taA.setText(temp);
                }
            });
            try {
                Thread.sleep(Integer.parseInt(tfSleep.getText()));

            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    public class AddMatrixThread implements Runnable {

        int s1, s2;

        public AddMatrixThread(int s1, int s2) {
            this.s1 = s1;
            this.s2 = s2;
        }

        @Override
        public void run() {

            matrixD[s1][s2] += matrixA[s1][s2] + matrixB[s1][s2];
            String strD = "";
            for (int i = 0; i < matrixD.length; i++) {
                for (int j = 0; j < matrixD[0].length; j++) {
                    if (matrixD[i][j] == 0) {
                        strD += "  ";
                    } else {
                        strD += matrixD[i][j] + " ";
                    }
                }
                strD += "\n";
            }
            final String temp = strD;
            SwingUtilities.invokeLater(new Runnable() {
                public void run() {
                    taB.setText(temp);
                }
            });
            try {
                Thread.sleep(Integer.parseInt(tfSleep.getText()));
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }
}

