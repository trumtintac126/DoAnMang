/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package matrix;

import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.util.Random;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PiePlot3D;
import org.jfree.data.general.DefaultPieDataset;

/**
 *
 * @author Nguyen Tri
 */
public class MultiMatrix extends javax.swing.JFrame {

    public MultiMatrix() {
        initComponents();
        panelmatrix.removeAll();
        lbTime1.setVisible(false);
        lbTime2.setVisible(false);
        txtmB.setEditable(false);
        txtmB.setEnabled(false);
        txtnB.setEnabled(false);
    }
    public static int[][] c;
    public static int[][] a;
    public static int[][] b;
    static int n, temp, MIN = 0;
    static int[][] d ;
    int[] x = new int[100];
    int[] chuaxet = new int[100];
    int kq[] = new int[100];
    static int e = 1;

    public static int[][] genNewMatrixandSaveFile(int m, int n, String filename) throws Exception {
        FileOutputStream fos = new FileOutputStream(filename, false);
        PrintWriter pw = new PrintWriter(fos);
        pw.println(m + " " + n);
        int[][] mat = new int[m][n];
        Random ran = new Random();
        int i, j;
        for (i = 0; i < m; i++) {
            for (j = 0; j < n; j++) {
                mat[i][j] = ran.nextInt(10);
                pw.print(mat[i][j] + " ");
            }
            pw.println();
        }
        pw.close();
        return mat;
    }

    public static int[][] loadMatrix(String filename) throws Exception {
        Scanner s = new Scanner(new FileInputStream(filename));
        int rows = s.nextInt();
        int cols = s.nextInt();
        int mat[][] = new int[rows][cols];
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                mat[i][j] = s.nextInt();
            }

        }
        return mat;
    }

    public static void storeMatrix(int c[][], String filename) throws Exception {
        int rows = c.length;
        int cols = c[0].length;
        PrintWriter pw = new PrintWriter(new FileOutputStream(filename));
        pw.println("rows   " + rows + "      columns     " + cols);

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                pw.print(c[i][j] + "    ");

            }
            pw.println();
        }
        pw.close();
    }

    public static void displayMatrix(int c[][], String filename) throws Exception {
        int rows = c.length;
        int cols = c[0].length;
        System.out.println("rows   " + rows + "      columns     " + cols);

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                System.out.print(c[i][j] + "    ");

            }
            System.out.println();
        }

    }

    public static class Thread1 extends Thread {

        @Override
        public void run() {
            if (a[0].length != b.length) {
                System.out.println("Muon nhan 2 ma tran thi so co cua ma tran A = so hang cua ma tran B");
                return;
            } else {
                int m = a.length;
                int n = b[0].length;
                int k = (a.length) / 4;

                for (int i = 0; i <= k; i++) {
                    for (int j = 0; j < n; j++) {
                        for (int l = 0; l < b.length; l++) {
                            c[i][j] = c[i][j] + a[i][l] * b[l][j];
                        }
                    }
                }
            }
        }
    }

    public static class Thread2 extends Thread {

        @Override
        public void run() {
            if (a[0].length != b.length) {
                System.out.println("Muon nhan 2 ma tran thi so co cua ma tran A = so hang cua ma tran B");
                return;
            } else {
                int m = a.length;
                int n = b[0].length;
                int k = (a.length) / 2 + 1;
                int s = ((a.length) / 4) + 1;

                for (int i = s; i < k; i++) {
                    for (int j = 0; j < n; j++) {
                        for (int l = 0; l < b.length; l++) {
                            c[i][j] = c[i][j] + a[i][l] * b[l][j];

                        }

                    }

                }
            }

        }
    }

    public static class Thread3 extends Thread {

        @Override
        public void run() {
            if (a[0].length != b.length) {
                System.out.println("Muon nhan 2 ma tran thi so co cua ma tran A = so hang cua ma tran B");
                return;
            } else {
                int m = a.length;
                int n = b[0].length;
                int k = ((3 * (a.length)) / 4) + 1;
                int s = (a.length) / 2 + 1;

                for (int i = s; i < k; i++) {
                    for (int j = 0; j < n; j++) {
                        for (int l = 0; l < b.length; l++) {
                            c[i][j] = c[i][j] + a[i][l] * b[l][j];

                        }

                    }

                }
            }
        }
    }

    public static class Thread4 extends Thread {

        @Override
        public void run() {
            if (a[0].length != b.length) {
                System.out.println("Muon nhan 2 ma tran thi so co cua ma tran A = so hang cua ma tran B");
                return;
            } else {
                int m = a.length;
                int n = b[0].length;
                int k = ((3 * (a.length)) / 4) + 1;

                for (int i = k; i < m; i++) {
                    for (int j = 0; j < n; j++) {
                        for (int l = 0; l < b.length; l++) {
                            c[i][j] = c[i][j] + a[i][l] * b[l][j];

                        }

                    }

                }
            }
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanelMatrixA = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtmA = new javax.swing.JTextField();
        txtnA = new javax.swing.JTextField();
        btnSaveA = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txtmB = new javax.swing.JTextField();
        txtnB = new javax.swing.JTextField();
        btnSaveB = new javax.swing.JButton();
        panelmatrix = new javax.swing.JPanel();
        panelTSP = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        txtthanhpho = new javax.swing.JTextField();
        btnSaveSothanhpho = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        btnSoSanhTSP = new javax.swing.JButton();
        btnthreadTSP = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        txtThreadTSP = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        txtdonluongTSP = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        txtchiphithread = new javax.swing.JTextField();
        txtchiphidon = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtduongdithread = new javax.swing.JTextArea();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtdungdidon = new javax.swing.JTextArea();
        panelTSPThread = new javax.swing.JPanel();
        btnSoSanh = new javax.swing.JButton();
        btnThread = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        txtTime1 = new javax.swing.JTextField();
        lbTime1 = new javax.swing.JLabel();
        btnNoThread = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        txtTime2 = new javax.swing.JTextField();
        lbTime2 = new javax.swing.JLabel();
        panelmatrixthread = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("MULTIMATRIX");
        setName("frmMain"); // NOI18N

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 0, 0));
        jLabel1.setText("Nhập số hàng Matrix A");

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 0, 0));
        jLabel2.setText("Nhập số cột Matrix A");

        btnSaveA.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnSaveA.setForeground(new java.awt.Color(255, 0, 51));
        btnSaveA.setText("Save File");
        btnSaveA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSaveAActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 0, 0));
        jLabel3.setText("Nhập số hàng Matrix B");

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 0, 0));
        jLabel4.setText("Nhập số cột Matrix B");

        btnSaveB.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnSaveB.setForeground(new java.awt.Color(255, 0, 51));
        btnSaveB.setText("Save File");
        btnSaveB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSaveBActionPerformed(evt);
            }
        });

        DefaultPieDataset dataset = new DefaultPieDataset();
        JFreeChart chartC = ChartFactory.createPieChart3D("SO SANH THOI GIAN", dataset, true, true, false);

        javax.swing.GroupLayout jPanelMatrixALayout = new javax.swing.GroupLayout(jPanelMatrixA);
        jPanelMatrixA.setLayout(jPanelMatrixALayout);
        jPanelMatrixALayout.setHorizontalGroup(
            jPanelMatrixALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelMatrixALayout.createSequentialGroup()
                .addGroup(jPanelMatrixALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanelMatrixALayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanelMatrixALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanelMatrixALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtmA, javax.swing.GroupLayout.DEFAULT_SIZE, 77, Short.MAX_VALUE)
                            .addComponent(txtnA))
                        .addGap(33, 33, 33)
                        .addComponent(btnSaveA, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanelMatrixALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(35, 35, 35)
                        .addGroup(jPanelMatrixALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanelMatrixALayout.createSequentialGroup()
                                .addComponent(txtnB)
                                .addGap(48, 48, 48))
                            .addGroup(jPanelMatrixALayout.createSequentialGroup()
                                .addComponent(txtmB, javax.swing.GroupLayout.DEFAULT_SIZE, 91, Short.MAX_VALUE)
                                .addGap(49, 49, 49)))
                        .addComponent(btnSaveB, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(panelmatrix, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanelMatrixALayout.setVerticalGroup(
            jPanelMatrixALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelMatrixALayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanelMatrixALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btnSaveA, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanelMatrixALayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(jPanelMatrixALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtmA, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanelMatrixALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtnA, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanelMatrixALayout.createSequentialGroup()
                        .addGroup(jPanelMatrixALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtmB, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanelMatrixALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtnB, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(btnSaveB, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addComponent(panelmatrix, javax.swing.GroupLayout.PREFERRED_SIZE, 356, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        dataset.setValue("Đa luồng", 1000);
        dataset.setValue("Đơn luồng", 2000);
        chartC.setTitle("Biểu đồ thể hiện thời gian nhân 2 ma trận");
        PiePlot3D plotC = (PiePlot3D) chartC.getPlot();
        plotC.setForegroundAlpha(0.5f);
        JFreeChart pieChart = chartC;
        ChartPanel chartPanel = new ChartPanel(pieChart);
        chartPanel.setPreferredSize(new Dimension(200, 200));
        chartPanel.setMouseWheelEnabled(true);
        chartPanel.setZoomAroundAnchor(true);

        panelmatrix.add(chartPanel);
        panelmatrix.revalidate();
        panelmatrix.repaint();

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(204, 0, 51));
        jLabel7.setText("BÀI TOÁN TSP");

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(204, 0, 51));
        jLabel8.setText("Số thành phố");

        txtthanhpho.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        txtthanhpho.setForeground(new java.awt.Color(204, 0, 51));

        btnSaveSothanhpho.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btnSaveSothanhpho.setForeground(new java.awt.Color(204, 0, 51));
        btnSaveSothanhpho.setText("Save File");
        btnSaveSothanhpho.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSaveSothanhphoActionPerformed(evt);
            }
        });

        btnSoSanhTSP.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btnSoSanhTSP.setForeground(new java.awt.Color(204, 0, 0));
        btnSoSanhTSP.setText("SO SÁNH");
        btnSoSanhTSP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSoSanhTSPActionPerformed(evt);
            }
        });

        btnthreadTSP.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btnthreadTSP.setForeground(new java.awt.Color(204, 0, 51));
        btnthreadTSP.setText("Giải đa luồng");
        btnthreadTSP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnthreadTSPActionPerformed(evt);
            }
        });

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(204, 0, 51));
        jLabel9.setText("TIME");

        txtThreadTSP.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        txtThreadTSP.setForeground(new java.awt.Color(204, 0, 51));

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(204, 0, 51));
        jLabel10.setText("MS");

        jButton1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jButton1.setForeground(new java.awt.Color(204, 0, 51));
        jButton1.setText("Giải đơn luồng");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(204, 0, 51));
        jLabel11.setText("TIME");

        txtdonluongTSP.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        txtdonluongTSP.setForeground(new java.awt.Color(204, 0, 51));

        jLabel12.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(204, 0, 51));
        jLabel12.setText("MS");

        txtchiphithread.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        txtchiphithread.setForeground(new java.awt.Color(204, 0, 51));

        txtchiphidon.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        txtchiphidon.setForeground(new java.awt.Color(255, 0, 51));

        txtduongdithread.setColumns(20);
        txtduongdithread.setFont(new java.awt.Font("Monospaced", 1, 18)); // NOI18N
        txtduongdithread.setForeground(new java.awt.Color(204, 0, 51));
        txtduongdithread.setRows(5);
        jScrollPane1.setViewportView(txtduongdithread);

        txtdungdidon.setColumns(20);
        txtdungdidon.setFont(new java.awt.Font("Monospaced", 1, 18)); // NOI18N
        txtdungdidon.setForeground(new java.awt.Color(204, 0, 51));
        txtdungdidon.setRows(5);
        jScrollPane2.setViewportView(txtdungdidon);

        javax.swing.GroupLayout panelTSPLayout = new javax.swing.GroupLayout(panelTSP);
        panelTSP.setLayout(panelTSPLayout);
        panelTSPLayout.setHorizontalGroup(
            panelTSPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelTSPLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelTSPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelTSPLayout.createSequentialGroup()
                        .addGroup(panelTSPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(panelTSPThread, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(panelTSPLayout.createSequentialGroup()
                                .addGroup(panelTSPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel7)
                                    .addGroup(panelTSPLayout.createSequentialGroup()
                                        .addComponent(jLabel8)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(txtthanhpho, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(btnSaveSothanhpho, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(panelTSPLayout.createSequentialGroup()
                                        .addGroup(panelTSPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                            .addGroup(panelTSPLayout.createSequentialGroup()
                                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 704, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(txtchiphithread, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(panelTSPLayout.createSequentialGroup()
                                                .addComponent(jScrollPane2)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(txtchiphidon, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelTSPLayout.createSequentialGroup()
                        .addComponent(btnthreadTSP)
                        .addGroup(panelTSPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(panelTSPLayout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btnSoSanhTSP)
                                .addGap(346, 346, 346))
                            .addGroup(panelTSPLayout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel9)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(txtThreadTSP, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel10)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jButton1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel11)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtdonluongTSP, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel12)
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))))
        );
        panelTSPLayout.setVerticalGroup(
            panelTSPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelTSPLayout.createSequentialGroup()
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(panelTSPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnSaveSothanhpho, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(txtthanhpho))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelTSPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtchiphithread, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelTSPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtchiphidon, javax.swing.GroupLayout.DEFAULT_SIZE, 37, Short.MAX_VALUE)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(panelTSPThread, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(panelTSPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelTSPLayout.createSequentialGroup()
                        .addGroup(panelTSPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton1)
                            .addComponent(jLabel11)
                            .addComponent(txtdonluongTSP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel12))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnSoSanhTSP)
                        .addGap(28, 28, 28))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelTSPLayout.createSequentialGroup()
                        .addGroup(panelTSPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnthreadTSP)
                            .addComponent(jLabel9)
                            .addComponent(txtThreadTSP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel10))
                        .addGap(58, 58, 58))))
        );

        btnSoSanh.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btnSoSanh.setForeground(new java.awt.Color(255, 0, 51));
        btnSoSanh.setText("So sánh");
        btnSoSanh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSoSanhActionPerformed(evt);
            }
        });

        btnThread.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnThread.setForeground(new java.awt.Color(255, 0, 0));
        btnThread.setText("Giải Đa Luồng");
        btnThread.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThreadActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(153, 0, 51));
        jLabel5.setText("Time");

        txtTime1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        txtTime1.setForeground(new java.awt.Color(153, 0, 51));

        lbTime1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        lbTime1.setForeground(new java.awt.Color(255, 0, 0));
        lbTime1.setText("ms");

        btnNoThread.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnNoThread.setForeground(new java.awt.Color(255, 0, 0));
        btnNoThread.setText("Giải Đơn Luồng");
        btnNoThread.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNoThreadActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(153, 0, 51));
        jLabel6.setText("Time");

        txtTime2.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        txtTime2.setForeground(new java.awt.Color(153, 0, 51));

        lbTime2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        lbTime2.setForeground(new java.awt.Color(255, 0, 0));
        lbTime2.setText("ms");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(354, 354, 354)
                        .addComponent(btnSoSanh, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(btnThread, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtTime1, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(lbTime1, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnNoThread, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtTime2, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(lbTime2, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanelMatrixA, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(panelmatrixthread, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addComponent(panelTSP, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(panelTSP, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanelMatrixA, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(panelmatrixthread, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(32, 32, 32)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnThread, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtTime1, javax.swing.GroupLayout.DEFAULT_SIZE, 51, Short.MAX_VALUE)
                            .addComponent(lbTime1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnNoThread, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtTime2, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lbTime2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(11, 11, 11)
                        .addComponent(btnSoSanh, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(53, 53, 53))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnThreadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThreadActionPerformed
        try {
            long t1 = System.currentTimeMillis();
            a = loadMatrix("a1.txt");
            b = loadMatrix("b1.txt");
            c = new int[a.length][b[0].length];

            Thread1 m1 = new Thread1();
            Thread2 m2 = new Thread2();
            Thread3 m3 = new Thread3();
            Thread4 m4 = new Thread4();
            m1.start();
            m2.start();
            m3.start();
            m4.start();
//            m1.join();
//            m2.join();
//            m3.join();
//            m4.join();

            storeMatrix(c, "xx.txt");

//            txtMatranCDaluong.setWrapStyleWord(true);
//            //txtMatraA.setLineWrap(true);bỏ
//
//            for (int i = 0; i < c.length; i++) {
//                for (int j = 0; j < c[i].length; j++) {
//                    txtMatranCDaluong.append(Integer.valueOf(c[i][j]).toString() + " ");
//                }
//                txtMatranCDaluong.append("\n");
//            }
            long t2 = System.currentTimeMillis();
            String time = String.valueOf(t2 - t1);
            txtTime1.setText(time);
            lbTime1.setVisible(true);
        } catch (Exception ex) {
            Logger.getLogger(MultiMatrix.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnThreadActionPerformed

    private void btnNoThreadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNoThreadActionPerformed
        try {
            long t1 = System.currentTimeMillis();
            a = loadMatrix("a1.txt");
            b = loadMatrix("b1.txt");
            c = new int[a.length][b[0].length];
            if (a[0].length != b.length) {
                System.out.println("Muon nhan 2 ma tran thi so co cua ma tran A = so hang cua ma tran B");
                return;
            } else {
                int m = a.length;
                int n = b[0].length;
                for (int i = 0; i < m; i++) {
                    for (int j = 0; j < n; j++) {
                        for (int l = 0; l < b.length; l++) {
                            c[i][j] = c[i][j] + a[i][l] * b[l][j];                            
                        }                        
                    }
                    Thread.sleep(50);
                }
            }
            storeMatrix(c, "xxx.txt");
//            txtMatrixDonluong.setWrapStyleWord(true);
//            for (int i = 0; i < c.length; i++) {
//                for (int j = 0; j < c[i].length; j++) {
//                    txtMatrixDonluong.append(Integer.valueOf(c[i][j]).toString() + " ");
//                }
//                txtMatrixDonluong.append("\n");
//            }
            long t2 = System.currentTimeMillis();
            String time = String.valueOf(t2 - t1);
            txtTime2.setText(time);
            lbTime2.setVisible(true);
        } catch (Exception ex) {
            Logger.getLogger(MultiMatrix.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnNoThreadActionPerformed

    private void btnSoSanhActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSoSanhActionPerformed
        DefaultPieDataset dataset = new DefaultPieDataset();
        JFreeChart chartC = ChartFactory.createPieChart3D("SO SANH THOI GIAN", dataset, true, true, false);
        String timeThread = txtTime1.getText();
        String time2 = txtTime2.getText();
        double time1 = Double.parseDouble(timeThread);
        double time2db = Double.parseDouble(time2);

        dataset.setValue("Đa luồng", time1);
        dataset.setValue("Đơn luồng", time2db);
        chartC.setTitle("Biểu đồ thể hiện thời gian nhân 2 ma trận");
        PiePlot3D plotC = (PiePlot3D) chartC.getPlot();
        plotC.setForegroundAlpha(0.5f);
        JFreeChart pieChart = chartC;
        ChartPanel chartPanel = new ChartPanel(pieChart);
        chartPanel.setPreferredSize(new Dimension(700, 300));
        chartPanel.setMouseWheelEnabled(true);
        chartPanel.setZoomAroundAnchor(true);
        panelmatrix.revalidate();
        panelmatrix.repaint();
        panelmatrix.add(chartPanel);
    }//GEN-LAST:event_btnSoSanhActionPerformed

    private void btnSaveAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveAActionPerformed

        txtnB.setEnabled(true);
        try {
            if (txtmA.getText().length() == 0) {
                JOptionPane.showMessageDialog(null, "Bạn chưa nhập liệu số dòng của ma trận A");
                txtmA.requestFocus();
                return;
            }
            if (txtnA.getText().length() == 0) {
                JOptionPane.showMessageDialog(null, "Bạn chưa nhập liệu số cột của ma trận A");
                txtnA.requestFocus();
                return;
            }
            int m = Integer.parseInt(txtmA.getText());
            int n = Integer.parseInt(txtnA.getText());
            genNewMatrixandSaveFile(m, n, "a1.txt");
            //them
            //            a = loadMatrix("a1.txt");
            //
            //            txtMatraA.setWrapStyleWord(true);
            //            //txtMatraA.setLineWrap(true);them
            //
            //            for (int i = 0; i < a.length; i++) {
            //                for (int j = 0; j < a[i].length; j++) {
            //                    txtMatraA.append(Integer.valueOf(a[i][j]).toString() + " ");
            //                    //System.out.print(a[i][j] + "    ");
            //                }
            //                //System.out.println("\n");them
            //                txtMatraA.append("\n");
            //            }
            //

            JOptionPane.showMessageDialog(null, "Lưu ma trận thành công");
            txtmB.setText(txtnA.getText());
            txtmB.setEnabled(true);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Bạn nhập chưa đúng kiểu dữ liệu xin vui lòng nhập lại");
            txtmA.setText("");
            txtnA.setText("");
            txtmA.requestFocus();
        }
    }//GEN-LAST:event_btnSaveAActionPerformed

    private void btnSaveBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveBActionPerformed
        try {
//            if (txtmB.getText().length() == 0) {
//                JOptionPane.showMessageDialog(null, "Bạn chưa nhập liệu số dòng của ma trận A");
//                txtmB.requestFocus();
//                return;
//            }
            if (txtnB.getText().length() == 0) {
                JOptionPane.showMessageDialog(null, "Bạn chưa nhập liệu số cột của ma trận A");
                txtnB.requestFocus();
                return;
            }
            txtmB.setEditable(false);
            int m = Integer.parseInt(txtnA.getText());
            int n = Integer.parseInt(txtnB.getText());
            genNewMatrixandSaveFile(m, n, "b1.txt");
            //them
            //            b = loadMatrix("b1.txt");
            //
            //            txtMatranB.setWrapStyleWord(true);
            //            //txtMatraA.setLineWrap(true);
            //
            //            for (int i = 0; i < b.length; i++) {
            //                for (int j = 0; j < b[i].length; j++) {
            //                    txtMatranB.append(Integer.valueOf(b[i][j]).toString() + " ");
            //                    //System.out.print(b[i][j] + "    ");
            //                }
            //                //System.out.println("\n");
            //                txtMatranB.append("\n");
            //            }
            //

            JOptionPane.showMessageDialog(null, "Lưu ma trận thành công");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Bạn nhập chưa đúng kiểu dữ liệu xin vui lòng nhập lại");
            txtmB.setText("");
            txtnB.setText("");
            txtmB.requestFocus();
        }
    }//GEN-LAST:event_btnSaveBActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        try {
            long t1 = System.currentTimeMillis();
            d = loadMatrixTSP("tsp.txt");
            x[1] = 1;
            for (int i = 2; i <= n; i++) {
                chuaxet[i] = 1;
            }
            Try(2);
            txtduongdithread.setWrapStyleWord(true);
            txtduongdithread.setLineWrap(true);
            txtduongdithread.setText("T1->");
            for (int i = 2; i <= n; i++) {
                txtduongdithread.append(("T" + kq[i]).toString() + "-> ");
                Thread.sleep(1500);
            }
            txtduongdithread.append("T1");
            int sum = MIN;
            String chiphi = String.valueOf(sum);
            txtchiphithread.setText(chiphi);
            long t2 = System.currentTimeMillis();
            String time = String.valueOf(t2 - t1);
            txtdonluongTSP.setText(time);

        } catch (Exception ex) {
            Logger.getLogger(MultiMatrix.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void btnthreadTSPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnthreadTSPActionPerformed
        try {
            long t1 = System.currentTimeMillis();
            d = loadMatrixTSP("tsp.txt");
            x[1] = 1;
            for (int i = 2; i <= n; i++) {
                chuaxet[i] = 1;
            }
            Try(2);
            txtdungdidon.setWrapStyleWord(true);
            txtdungdidon.setLineWrap(true);
            txtdungdidon.setText("T1->");
            for (int i = 2; i <= n; i++) {
                txtdungdidon.append(("T" + kq[i]).toString() + "-> ");
                Thread.sleep(500);
            }
            txtdungdidon.append("T1");
            int sum = MIN;
            String chiphi = String.valueOf(sum);
            txtchiphidon.setText(chiphi);
            long t2 = System.currentTimeMillis();
            String time = String.valueOf(t2 - t1);
            txtThreadTSP.setText(time);

        } catch (Exception ex) {
            Logger.getLogger(MultiMatrix.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnthreadTSPActionPerformed

    private void btnSoSanhTSPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSoSanhTSPActionPerformed
        DefaultPieDataset dataset = new DefaultPieDataset();
        JFreeChart chartC = ChartFactory.createPieChart3D("SO SANH THOI GIAN", dataset, true, true, false);
        String timeThread = txtThreadTSP.getText();
        String time2 = txtdonluongTSP.getText();
        double time1 = Double.parseDouble(timeThread);
        double time2db = Double.parseDouble(time2);

        dataset.setValue("Đa luồng", time1);
        dataset.setValue("Đơn luồng", time2db);
        chartC.setTitle("Biểu đồ thể hiện thời gian TSP");
        PiePlot3D plotC = (PiePlot3D) chartC.getPlot();
        plotC.setForegroundAlpha(0.5f);
        JFreeChart pieChart = chartC;
        ChartPanel chartPanel = new ChartPanel(pieChart);
        chartPanel.setPreferredSize(new Dimension(700, 300));
        chartPanel.setMouseWheelEnabled(true);
        chartPanel.setZoomAroundAnchor(true);
        panelTSPThread.revalidate();
        panelTSPThread.repaint();
        panelTSPThread.add(chartPanel);
    }//GEN-LAST:event_btnSoSanhTSPActionPerformed

    private void btnSaveSothanhphoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveSothanhphoActionPerformed
        try {
            if (txtthanhpho.getText().length() == 0) {
                JOptionPane.showMessageDialog(null, "Bạn chưa nhập liệu số dòng của ma trận A");
                txtthanhpho.requestFocus();
                return;
            }
            n = Integer.parseInt(txtthanhpho.getText());
            genNewMatrixandSaveFileTSP(n, "tsp.txt");
            JOptionPane.showMessageDialog(null, "Lưu ma trận chi phí thành công");

        } catch (Exception e) {

        }
    }//GEN-LAST:event_btnSaveSothanhphoActionPerformed

    public static int[][] genNewMatrixandSaveFileTSP(int m, String filename) throws Exception {
        FileOutputStream fos = new FileOutputStream(filename, false);
        PrintWriter pw = new PrintWriter(fos);
        pw.println(m);
        int[][] mat = new int[m + 1][m + 1];
        Random ran = new Random();
        int i, j;
        for (i = 1; i <= m; i++) {
            for (j = i; j <= m; j++) {
                int value = ran.nextInt(9) + 1;
                if (i == j) {
                    mat[i][j] = 0;
                } else {
                    mat[i][j] = value;
                    mat[j][i] = value;
                }
            }
        }
        for (i = 1; i <= m; i++) {
            for (j = 1; j <= m; j++) {
                pw.print(mat[i][j] + " ");
            }
            pw.println();
        }
        pw.close();
        return mat;
    }

    public static int[][] loadMatrixTSP(String filename) throws Exception {
        Scanner s = new Scanner(new FileInputStream(filename));
        int rows = s.nextInt();
        int mat[][] = new int[rows + 1][rows + 1];
        for (int i = 1; i <= rows; i++) {
            for (int j = 1; j <= rows; j++) {
                mat[i][j] = s.nextInt();
            }

        }
        return mat;
    }

    public void Try(int i) {
        for (int j = 2; j <= n; j++) {
            if (chuaxet[j] == 1)//gặp thành phố chưa đi qua 
            {
                x[i] = j;
                chuaxet[j] = 0;
                if (i == n) {
                    //work();
                    int S = 0;
                    for (int k = 1; k < n; k++) {
                        S += d[x[k]][x[k + 1]];
                    }
                    S += d[x[n]][1];
                    if (S < MIN || e == 1) {
                        e = 0;
                        MIN = S;
                        for (int k = 1; k <= n; k++) {
                            kq[k] = x[k];
                        }
                    }
                } else {
                    Try(i + 1);
                }
                chuaxet[j] = 1; //bỏ đánh dấu
            }
        }
    }

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MultiMatrix().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnNoThread;
    private javax.swing.JButton btnSaveA;
    private javax.swing.JButton btnSaveB;
    private javax.swing.JButton btnSaveSothanhpho;
    public javax.swing.JButton btnSoSanh;
    private javax.swing.JButton btnSoSanhTSP;
    private javax.swing.JButton btnThread;
    private javax.swing.JButton btnthreadTSP;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanelMatrixA;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    public javax.swing.JLabel lbTime1;
    public javax.swing.JLabel lbTime2;
    private javax.swing.JPanel panelTSP;
    public javax.swing.JPanel panelTSPThread;
    public javax.swing.JPanel panelmatrix;
    public javax.swing.JPanel panelmatrixthread;
    private javax.swing.JTextField txtThreadTSP;
    public javax.swing.JTextField txtTime1;
    public javax.swing.JTextField txtTime2;
    private javax.swing.JTextField txtchiphidon;
    private javax.swing.JTextField txtchiphithread;
    private javax.swing.JTextField txtdonluongTSP;
    private javax.swing.JTextArea txtdungdidon;
    private javax.swing.JTextArea txtduongdithread;
    public javax.swing.JTextField txtmA;
    public javax.swing.JTextField txtmB;
    public javax.swing.JTextField txtnA;
    public javax.swing.JTextField txtnB;
    private javax.swing.JTextField txtthanhpho;
    // End of variables declaration//GEN-END:variables
}
