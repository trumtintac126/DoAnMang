/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package matrix;

import javax.swing.JPanel;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.general.PieDataset;
import org.jfree.ui.RefineryUtilities;

/**
 *
 * @author Nguyen Tri
 */
public class ChartSoSanh extends javax.swing.JPanel {

    /**
     * Creates new form ChartSoSanh
     */
    public ChartSoSanh() {
        initComponents();
    }

   static String time11,time12;
    public ChartSoSanh(String title,String time1,String time2) {
        initComponents();
        time11 = time1;
        time12 = time2;
//        setSize(500, 600);
        
    }

    private static PieDataset createDataset() {
        DefaultPieDataset dataset = new DefaultPieDataset();
        try {
            String time1 = time11;
            int time111 = Integer.parseInt(time1);
            String time2 = time12;
            int time112 = Integer.parseInt(time2);
            dataset.setValue("Đa luồng", time111);
            dataset.setValue("Đơn luồng", time112);

        } catch (Exception ex) {
            System.out.println("not a number");
        }
//        DefaultPieDataset dataset = new DefaultPieDataset();
//        dataset.setValue("Đa luồng", new Double(2));
//        dataset.setValue("Đơn luồng", new Double(20));
//        dataset.setValue("MotoG", new Double(40));
//        dataset.setValue("Nokia Lumia", new Double(10));
        return dataset;
    }

    private static JFreeChart createChart(PieDataset dataset) {
        JFreeChart chart = ChartFactory.createPieChart(
                "So sánh thời gian chạy", // chart title 
                dataset, // data    
                true, // include legend   
                true,
                false);

        return chart;
    }

    public static JPanel createDemoPanel() {
        JFreeChart chart = createChart(createDataset());
        return new ChartPanel(chart);
    }



                    
    /**
     * @param args the command line arguments
     */
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 598, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 441, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
